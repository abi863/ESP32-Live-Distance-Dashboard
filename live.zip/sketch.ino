#define BLYNK_TEMPLATE_ID "TMPL3FX1qbA-7"
#define BLYNK_TEMPLATE_NAME "HC SR04 DISTANCE,MONITOR."
#define BLYNK_AUTH_TOKEN "n0sra6oGxSVtFWWrrQMNU1SDOLvIIdcg"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>

#define TRIG_PIN 5
#define ECHO_PIN 18

char ssid[] = "Wokwi-GUEST";
char pass[] = "";

BlynkTimer timer;

void sendDistance()
{
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);

  if (duration == 0) {
    Serial.println("No echo received");
    return;
  }

  float distance = duration / 58.0;

  if (distance < 2) distance = 2;
  if (distance > 400) distance = 400;

  Serial.print("Distance: ");
  Serial.print(distance, 1);
  Serial.println(" cm");

  // Send to Blynk V0
  Blynk.virtualWrite(V0, distance);
}

void setup()
{
  Serial.begin(115200);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  digitalWrite(TRIG_PIN, LOW);

  Serial.println("HC-SR04 Blynk Monitor");

  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);

  timer.setInterval(1000L, sendDistance);
}

void loop()
{
  Blynk.run();
  timer.run();
}